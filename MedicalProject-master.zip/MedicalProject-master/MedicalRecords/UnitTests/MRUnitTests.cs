﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using MedicalRecordClassLibrary;
using MedicalRecords;

namespace UnitTests
{
    [TestClass]
    public class MRUnitTests
    {



        [TestMethod]
        public void DocLoginTest()
        {
            User u1 = new User();
            bool res = u1.Login("Doctor", "Password01");

            Assert.IsTrue(u1.AccessLevel == "doctor");
            Assert.IsTrue(res == true);
        }


        [TestMethod]
        public void RNloginTest()
        {
            User u1 = new User();
            bool res = u1.Login("Nurse", "Password01");

            Assert.IsTrue(u1.AccessLevel == "nurse");
            Assert.IsTrue(res == true);
        }


        [TestMethod]
        public void AnyUserTestFAIL()
        {
            User u1 = new User();
            bool res = u1.Login("Shannon", "ThisIsNotSecure");

            Assert.IsTrue(u1.AccessLevel == "none");
            Assert.IsTrue(res == false);
        }

        [TestMethod]
        public void PatientNameTest()
        {
            Patient_Information patient = new Patient_Information("0005", "Diane", "Johnson", "02/14/1978", "F", "03/10/2017", "Headache", "Peanuts^cats^dogs", "Insulin", "", "diabetes", "6.7");

            Assert.IsTrue(patient.FirstName == "Diane" && patient.LastName == "Johnson");
        }

        [TestMethod]
        public void PatientNameTest2()
        {
            Patient_Information patient = new Patient_Information("0005", "Diane", "Johnson", "02/14/1978", "F", "03/10/2017", "Headache", "Peanuts^cats^dogs", "Insulin", "", "diabetes", "6.7");

            Assert.IsTrue(patient.FirstName != string.Empty);
        }
                    
        
        [TestMethod]
        public void PatientAgeTest()
        {
            Patient_Information patient = new Patient_Information("0005", "Diane", "Johnson", "02/14/1978", "F", "03/10/2017", "Headache", "Peanuts^cats^dogs", "Insulin", "", "diabetes", "6.7");

            Assert.IsTrue(patient.Age == 39);
        }

        [TestMethod]
        public void PatientAgeTestFalse()
        {
            Patient_Information patient = new Patient_Information("0005", "Diane", "Johnson", "02/14/1978", "F", "03/10/2017", "Headache", "Peanuts^cats^dogs", "Insulin", "", "diabetes", "6.7");

            Assert.IsFalse(patient.Age == 45);
        }

        [TestMethod]
        public void PatientAllergyTest()

        {
            Patient_Information patient = new Patient_Information("0005", "Diane", "Johnson", "02/14/1978", "F", "03/10/2017", "Headache", "Peanuts^cats^dogs", "Insulin", "", "diabetes", "6.7");

            Assert.IsTrue(patient.AllergyList.Count == 3 & patient.AllergyList[1].allergyType == "cats");
        }

        [TestMethod]
        public void PatientAllergyTestfalse()
        {
            Patient_Information patient = new Patient_Information("0005", "Diane", "Johnson", "02/14/1978", "F", "03/10/2017", "Headache", "Peanuts^cats^dogs", "Insulin", "", "diabetes", "6.7");

            Assert.IsFalse(patient.AllergyList.Count == 2 & patient.AllergyList[0].allergyType == "cats");
        }



        [TestMethod]
        public void PatientDiabetesTest()
        {
            Patient_Information patient = new Patient_Information("0005", "Diane", "Johnson", "02/14/1978", "F", "03/10/2017", "Headache", "Peanuts^cats^dogs", "Insulin", "", "diabetes", "6.7");

            Assert.IsTrue(patient.HbA1c > 6.5);

        }

        [TestMethod]
        public void PatientDiabetesTestFalse()
        {
            Patient_Information patient = new Patient_Information("0005", "Diane", "Johnson", "02/14/1978", "F", "03/10/2017", "Headache", "Peanuts^cats^dogs", "Insulin", "", "diabetes", "6.7");

            Assert.IsFalse(patient.HbA1c < 6.5);

        }


        [TestMethod]
        public void PatientGenderTest()
        {
            Patient_Information patient = new Patient_Information("0005", "Diane", "Johnson", "02/14/1978", "F", "03/10/2017", "Headache", "Peanuts^cats^dogs", "Insulin", "", "diabetes", "6.7");

            Assert.IsTrue(patient.GenderShortString == "F");
        }

        [TestMethod]
        public void PatientGenderTestfalse()
        {
            Patient_Information patient = new Patient_Information("0005", "Diane", "Johnson", "02/14/1978", "F", "03/10/2017", "Headache", "Peanuts^cats^dogs", "Insulin", "", "diabetes", "6.7");

            Assert.IsFalse(patient.GenderShortString == "M");
        }


        [TestMethod]
        public void PatientDiagnosisTest()
        {
            Patient_Information patient = new Patient_Information("0005", "Diane", "Johnson", "02/14/1978", "F", "03/10/2017", "Headache", "Peanuts^cats^dogs", "Insulin", "", "diabetes^heart disease^obesity^chronic pain", "6.7");

            Assert.IsTrue(patient.DiagnosisList.Count == 4 & patient.DiagnosisList[2].Diagnosis == "obesity");
        }

        [TestMethod]
        public void PatientDiagnosisFailTest()
        {
            Patient_Information patient = new Patient_Information("0005", "Diane", "Johnson", "02/14/1978", "F", "03/10/2017", "Headache", "Peanuts^cats^dogs", "Insulin", "", "diabetes^heart disease^obesity^chronic pain", "6.7");

            Assert.IsFalse(patient.DiagnosisList.Count == 1 & patient.DiagnosisList[0].Diagnosis == "obesity");
        }

        [TestMethod]
        public void AdmitDateTest()
        {
            Patient_Information patient = new Patient_Information("0005", "Diane", "Johnson", "02/14/1978", "F", "03/10/2017", "Headache", "Peanuts^cats^dogs", "Insulin", "", "diabetes^heart disease^obesity^chronic pain", "6.7");

            Assert.IsTrue(patient.AdmitDate <= System.DateTime.Now);
        }

        [TestMethod]
        public void AdmitDateisNotinTheFuture()
        {
            Patient_Information patient = new Patient_Information("0005", "Diane", "Johnson", "02/14/1978", "F", "03/10/2017", "Headache", "Peanuts^cats^dogs", "Insulin", "", "diabetes^heart disease^obesity^chronic pain", "6.7");

            Assert.IsFalse(patient.AdmitDate > System.DateTime.Now);
        }

        [TestMethod]
        public void whoknowswhatthisoneis()
        {

        }

        }
    
            
            

    }

