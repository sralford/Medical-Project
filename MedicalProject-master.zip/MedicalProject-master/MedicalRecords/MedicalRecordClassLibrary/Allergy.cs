﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MedicalRecordClassLibrary
{
    public class Allergy
    {
        public string allergyType { get; set; }
    }
}
