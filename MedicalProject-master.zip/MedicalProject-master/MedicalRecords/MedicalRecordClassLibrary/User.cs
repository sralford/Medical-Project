﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MedicalRecordClassLibrary
{
   public class User
    {
        public string Username { get { return _username; } }
        private string _username;
        public string AccessLevel { get { return _accessLevel; } }
        private string _accessLevel;

        public User()
        {
            _username = "";
            _accessLevel = "none";
        }

        public bool Login(string userV, string passV)
        {
            _username = userV;
            _accessLevel = "none";

            // don't do this in the real world
            if ((_username == "Doctor") && (passV == "Password01"))
            {
                _accessLevel = "doctor";
                return true;
            }

            if ((_username == "Nurse") && (passV == "Password01"))
            {
                _accessLevel = "nurse";
                return true;
            }

            return false;
        }

        

    } // class User
} // namespace MedicalRecordClassLibrary
            

        
      


        

    

    

