﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MedicalRecordClassLibrary
{
    public class LabResult
    {
        #region Properties   
        // Fields and properties pertaining to Lab Results

      
        public string TestType { get; set; }
       
        public DateTime TestDate { get; set; }
        
        public string TestResult { get; set; }

    
    }

         #endregion

}



