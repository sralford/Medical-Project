﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MedicalRecordClassLibrary
{
    public class Patient_Information
    {
        public Patient_Information(string dbidV,string firstV,string lastV,string dobV,string genderV,string admitV,string complV,string allergyV,string medV,string labV,string diagV,string hbaV){
         _dbid          = Convert.ToInt32(dbidV);
         _firstName     = firstV;
         _lastName      = lastV;
         _dateOfBirth   = Convert.ToDateTime(dobV);
         _gender        = (genderV=="M" ? genderenum.MALE : genderenum.FEMALE);
         _admitDate     = Convert.ToDateTime(admitV);
         ChiefComplaint = complV;

         string[] sa;

         AllergyList = new List<Allergy>();
         if(allergyV.Length>0){
          sa = allergyV.Split('^');
          foreach(string s in sa)AllergyList.Add(new Allergy(){allergyType=s});
         }

         MedicationList = new List<CurrentMedications>();
         if(medV.Length>0){
          sa = medV.Split('^');
          foreach(string s in sa)MedicationList.Add(new CurrentMedications(){MedicationName=s});
         }

         LabResultList = new List<LabResult>();
         if(labV.Length>0){
          sa = labV.Split('^');
          foreach(string s in sa)LabResultList.Add(new LabResult(){TestType=s});
         }

         DiagnosisList = new List<PatientDiagnosis>();
         if(diagV.Length>0){
          sa = diagV.Split('^');
          foreach(string s in sa)DiagnosisList.Add(new PatientDiagnosis(){Diagnosis=s});
         }

         HbA1c = Convert.ToSingle(hbaV);
        }


        #region Properties

        private int _dbid;
        public int DBID {
            get{return _dbid;}
        }
        public string DBID5 {
            get{return _dbid.ToString("D5");}
        }

        private string _firstName;
        public string FirstName{
            get{return _firstName;}
        }

        private string _lastName;
        public string LastName
        {
            get{return _lastName;}
        }

        private DateTime _dateOfBirth;
        public DateTime DateOfBirth
        {
            get{return _dateOfBirth;}
        }

        public int Age{
         get{
          DateTime a = DateTime.Now, b = _dateOfBirth;
          return (
           (a.Year-b.Year-1) +
           ( ( (a.Month>b.Month) || ((a.Month==b.Month)&&(a.Day>=b.Day)) ) ? 1 : 0)
          );
         }
        }

        public string ChiefComplaint { get; set; }

        public enum genderenum {MALE,FEMALE};
        private genderenum _gender;
        public string GenderShortString
        {
            get{
             if(_gender==genderenum.MALE  )return "M";
             if(_gender==genderenum.FEMALE)return "F";
             return "?";
            }
        }

        public string PrimaryPhysician{get;set;}

        private DateTime _admitDate;
        public DateTime AdmitDate {
         get{return _admitDate;}
        }

        public float HbA1c{get;set;}

        public List<Allergy>            AllergyList;
        public List<CurrentMedications> MedicationList;
        public List<LabResult>          LabResultList;
        public List<PatientDiagnosis>   DiagnosisList;

        #endregion

    }

   
}
