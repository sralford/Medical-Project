﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MedicalRecordClassLibrary
{
    public class PatientDiagnosis
    {
      
        public string Diagnosis { get; set; }
        
        public string DoctorName { get; set; }
        
        public string DateDiagnosed { get; set; }
    }
}
