﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using genderenum = MedicalRecordClassLibrary.Patient_Information.genderenum;

namespace MedicalRecords {
 public partial class PatientDatabase : Window {



public MedicalRecordClassLibrary.User user;

public void LoadData(){
 try{
  PatientTable = new ObservableCollection<MedicalRecordClassLibrary.Patient_Information>();
  using (System.IO.StreamReader f = new System.IO.StreamReader("PatientData/Data.txt")){
   for(string inData=f.ReadLine();inData!=null;inData=f.ReadLine()){
    string[] sa = inData.Split('|');
    PatientTable.Add(
     new MedicalRecordClassLibrary.Patient_Information(
      sa[0],sa[1],sa[2],sa[3],sa[4],sa[5],sa[6],sa[7],sa[8],sa[9],sa[10],sa[11]
     )
    );
   }
   UI_PDB_PatientTable.ItemsSource = PatientTable;
  }
 }catch(Exception){}
}


public PatientDatabase(MedicalRecordClassLibrary.User userV){
 InitializeComponent();
 user = userV;
 LoadData();
}


private void UI_PDB_PatientTable_OnDblClick(object obj,MouseButtonEventArgs e){
 if(UI_PDB_PatientTable.SelectedIndex<0)return;
 (new PatientRecordScreen(this,PatientTable[UI_PDB_PatientTable.SelectedIndex])).Show();
}


private void Button_Click(object sender, RoutedEventArgs e){
 LoadData();

 if(UI_PDB_FirstName.Text.Trim().Length>0){
  string s = UI_PDB_FirstName.Text.Trim();
  ObservableCollection<MedicalRecordClassLibrary.Patient_Information> pList = new ObservableCollection<MedicalRecordClassLibrary.Patient_Information>();
  foreach(MedicalRecordClassLibrary.Patient_Information p in PatientTable){
   if(p.FirstName.IndexOf(s,StringComparison.OrdinalIgnoreCase)<0)continue;
   pList.Add(p);
  }
  PatientTable = pList;
 }

 if(UI_PDB_LastName.Text.Trim().Length>0){
  string s = UI_PDB_LastName.Text.Trim();
  ObservableCollection<MedicalRecordClassLibrary.Patient_Information> pList = new ObservableCollection<MedicalRecordClassLibrary.Patient_Information>();
  foreach(MedicalRecordClassLibrary.Patient_Information p in PatientTable){
   if(p.LastName.IndexOf(s,StringComparison.OrdinalIgnoreCase)<0)continue;
   pList.Add(p);
  }
  PatientTable = pList;
 }

 if(UI_PDB_ChiefComplaint.Text.Trim().Length>0){
  string s = UI_PDB_ChiefComplaint.Text.Trim();
  ObservableCollection<MedicalRecordClassLibrary.Patient_Information> pList = new ObservableCollection<MedicalRecordClassLibrary.Patient_Information>();
  foreach(MedicalRecordClassLibrary.Patient_Information p in PatientTable){
   if(p.ChiefComplaint.IndexOf(s,StringComparison.OrdinalIgnoreCase)<0)continue;
   pList.Add(p);
  }
  PatientTable = pList;
 }

 if(UI_PDB_DOB.Text.Trim().Length>0){
  string s = UI_PDB_DOB.Text.Trim();
  ObservableCollection<MedicalRecordClassLibrary.Patient_Information> pList = new ObservableCollection<MedicalRecordClassLibrary.Patient_Information>();
  foreach(MedicalRecordClassLibrary.Patient_Information p in PatientTable){
   if(p.DateOfBirth.ToString("MM'/'dd'/'yyyy").IndexOf(s,StringComparison.OrdinalIgnoreCase)<0)continue;
   pList.Add(p);
  }
  PatientTable = pList;
 }

 if(UI_PDB_Age.Text.Trim().Length>0){
  string s = UI_PDB_Age.Text.Trim();
  ObservableCollection<MedicalRecordClassLibrary.Patient_Information> pList = new ObservableCollection<MedicalRecordClassLibrary.Patient_Information>();
  foreach(MedicalRecordClassLibrary.Patient_Information p in PatientTable){
   if(p.Age.ToString().IndexOf(s,StringComparison.OrdinalIgnoreCase)<0)continue;
   pList.Add(p);
  }
  PatientTable = pList;
 }

 UI_PDB_PatientTable.ItemsSource = PatientTable;

 UI_PDB_FirstName     .Text = "";
 UI_PDB_LastName      .Text = "";
 UI_PDB_ChiefComplaint.Text = "";
 UI_PDB_DOB           .Text = "";
 UI_PDB_Age           .Text = "";
}


private ObservableCollection<MedicalRecordClassLibrary.Patient_Information> PatientTable;



 } // class PatientDatabase
} // namespace MedicalRecords
