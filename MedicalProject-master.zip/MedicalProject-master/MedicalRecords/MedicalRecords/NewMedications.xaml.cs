﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace MedicalRecords
{
    /// <summary>
    /// Interaction logic for NewMedications.xaml
    /// </summary>
    public partial class NewMedications : Window
    {
 
        private PatientRecordScreen parent;

        public NewMedications(PatientRecordScreen parentV)
        {
            InitializeComponent();
            parent = parentV;
        }

        private void button_Click(object sender, RoutedEventArgs e)
        {
            if(MedTextBox.Text.Length>0){
             parent.AddMedication(MedTextBox.Text);
             MessageBox.Show("New Medication Added. Add another.");
             MedTextBox.Text = "";
            }
        }

        private void button1_Click(object sender, RoutedEventArgs e)
        {
            if(MedTextBox.Text.Length>0){
             parent.AddMedication(MedTextBox.Text);
             MessageBox.Show("New Medication Added.");
            }
            this.Close();
        }
    }
}
