﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace MedicalRecords{
 public partial class PatientRecordScreen : Window{



private static BitmapImage NoImg = new BitmapImage(new Uri("pack://application:,,,/Images/nobody_m.original.jpg"));

private MedicalRecordClassLibrary.Patient_Information patient;
private PatientDatabase parent;

public PatientRecordScreen(PatientDatabase parentV,MedicalRecordClassLibrary.Patient_Information patientV){
 InitializeComponent();
 parent  = parentV;
 patient = patientV;

 // permissions
 dischargePatient.IsEnabled = false;
 newAllergy      .IsEnabled = false;
 newMedication   .IsEnabled = false;
 newLabResult    .IsEnabled = false;
 newDiagnosis    .IsEnabled = false;
 
 if(parent.user.AccessLevel=="doctor"){
  dischargePatient.IsEnabled = true;
  newAllergy      .IsEnabled = true;
  newMedication   .IsEnabled = true;
  newLabResult    .IsEnabled = true;
  newDiagnosis    .IsEnabled = true;
  
 }else if(parent.user.AccessLevel=="nurse"){
  newAllergy   .IsEnabled = true;
  newLabResult .IsEnabled = true;
                newMedication.IsEnabled = true;
                dischargePatient.IsEnabled = true;

 }

 LoadPatientData();
 this.Show();

 if( (parent.user.AccessLevel=="doctor") && (patient.HbA1c>6.5) ){
  foreach(MedicalRecordClassLibrary.PatientDiagnosis li in patient.DiagnosisList){
   if(li.Diagnosis.IndexOf("DIABETES",StringComparison.OrdinalIgnoreCase)>-1)return;
  }
  System.Windows.MessageBoxResult res = MessageBox.Show(
   "Patient has HbA1c indicative of diabetes. Add diabetic diagnosis?", "Patient Diabetic",System.Windows.MessageBoxButton.YesNo
  );
  if(res==System.Windows.MessageBoxResult.Yes)AddDiagnosis("DIABETES");
 }
}

private void LoadPatientData(){
 IDnum.Text            = patient.DBID.ToString("D5");
 patientFirstName.Text = patient.FirstName;
 patientLastName.Text  = patient.LastName;
 patientDOB.Text       = patient.DateOfBirth.ToString("MM/dd/yyyy",CultureInfo.InvariantCulture);
 patientAge.Text       = Convert.ToString(patient.Age);
 patientGender.Text    = patient.GenderShortString;
 patientAdmitDate.Text = patient.AdmitDate.ToString("MM/dd/yyyy",CultureInfo.InvariantCulture);
 patientChiefComplaint.Text = patient.ChiefComplaint;
 patientHbA1c.Text     = patient.HbA1c.ToString("0.00");

 patientAllergies.Items.Clear();
 foreach(MedicalRecordClassLibrary.Allergy li in patient.AllergyList){
  patientAllergies.Items.Add(li.allergyType);
 }

 patientMedications.Items.Clear();
 foreach(MedicalRecordClassLibrary.CurrentMedications li in patient.MedicationList){
  patientMedications.Items.Add(li.MedicationName);
 }

 patientLabResults.Items.Clear();
 foreach(MedicalRecordClassLibrary.LabResult li in patient.LabResultList){
  patientLabResults.Items.Add(li.TestType);
 }

 patientDiagnoses.Items.Clear();
 foreach(MedicalRecordClassLibrary.PatientDiagnosis li in patient.DiagnosisList){
  patientDiagnoses.Items.Add(li.Diagnosis);
 }

 try{
  string p = Directory.GetCurrentDirectory()+"./PatientData/"+patient.DBID5+"_img.jpg";
  image.Source = new BitmapImage(new Uri(p));
 }catch(Exception){
  image.Source = NoImg;
 } 
}


public void AddAllergy(string s){
 patient.AllergyList.Add(new MedicalRecordClassLibrary.Allergy(){allergyType=s});
 SavePatientData();
 LoadPatientData();
}

public void AddMedication(string s){
 patient.MedicationList.Add(new MedicalRecordClassLibrary.CurrentMedications(){MedicationName=s});
 SavePatientData();
 LoadPatientData();
}

public void AddLabResult(string s){
 patient.LabResultList.Add(new MedicalRecordClassLibrary.LabResult(){TestType=s});
 SavePatientData();
 LoadPatientData();
}

public void AddDiagnosis(string s){
 patient.DiagnosisList.Add(new MedicalRecordClassLibrary.PatientDiagnosis(){Diagnosis=s});
 SavePatientData();
 LoadPatientData();
}



public void SavePatientData(){
 try{
  string[] sa = File.ReadAllLines("PatientData/Data.txt");
  using (System.IO.StreamWriter f = new System.IO.StreamWriter("PatientData/Data.txt")){
   foreach(string s in sa){
    if(Convert.ToInt32(s.Split('|')[0])!=patient.DBID){
     f.WriteLine(s);
     continue;
    }

    string sOut = "";
    sOut += patient.DBID5     + '|';
    sOut += patient.FirstName + '|';
    sOut += patient.LastName  + '|';
    sOut += patient.DateOfBirth.ToString("MM/dd/yyyy",CultureInfo.InvariantCulture) + '|';
    sOut += patient.GenderShortString + '|';
    sOut += patient.AdmitDate.ToString("MM/dd/yyyy",CultureInfo.InvariantCulture) + '|';
    sOut += patient.ChiefComplaint + '|';

    bool firstPass = true;
    foreach(MedicalRecordClassLibrary.Allergy li in patient.AllergyList){
     if(!firstPass)sOut += '^';
     sOut += li.allergyType;
     firstPass = false;
    }
    sOut += '|';

    firstPass = true;
    foreach(MedicalRecordClassLibrary.CurrentMedications li in patient.MedicationList){
     if(!firstPass)sOut += '^';
     sOut += li.MedicationName;
     firstPass = false;
    }
    sOut += '|';

    firstPass = true;
    foreach(MedicalRecordClassLibrary.LabResult li in patient.LabResultList){
     if(!firstPass)sOut += '^';
     sOut += li.TestType;
     firstPass = false;
    }
    sOut += '|';

    firstPass = true;
    foreach(MedicalRecordClassLibrary.PatientDiagnosis li in patient.DiagnosisList){
     if(!firstPass)sOut += '^';
     sOut += li.Diagnosis;
     firstPass = false;
    }
    sOut += '|';

    sOut += patient.HbA1c.ToString("0.00");

    f.WriteLine(sOut);
   }
  }
 }catch(Exception){}
}


private void newMedication_OnClick(object sender,RoutedEventArgs e){(new NewMedications(this)).Show();}

private void newLabResult_OnClick(object sender,RoutedEventArgs e){(new NewLabResults(this)).Show();}

private void newDiagnosis_OnClick(object sender,RoutedEventArgs e){(new NewDiagnoses(this)).Show();}

private void newAllergy_Click(object sender, RoutedEventArgs e){(new NewAllergy(this)).Show();}



private void dischargePatient_Click(object sender, RoutedEventArgs e){
 System.Windows.MessageBoxResult res = MessageBox.Show(
  "Really discharge patient?", "Patient Discharge",System.Windows.MessageBoxButton.YesNo
 );
 if(res!=System.Windows.MessageBoxResult.Yes)return;

 try{
  string[] sa = File.ReadAllLines("PatientData/Data.txt");
  using (System.IO.StreamWriter f = new System.IO.StreamWriter("PatientData/Data.txt")){
   foreach(string s in sa){
    if(Convert.ToInt32(s.Split('|')[0])!=patient.DBID)f.WriteLine(s);
   }
  }
 }catch(Exception){}
 parent.LoadData();
 this.Close();
}



    }
}
