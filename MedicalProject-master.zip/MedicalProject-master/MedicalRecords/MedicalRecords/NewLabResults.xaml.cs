﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace MedicalRecords
{
    /// <summary>
    /// Interaction logic for NewLabResults.xaml
    /// </summary>
    public partial class NewLabResults : Window
    {

        private PatientRecordScreen parent;

        public NewLabResults(PatientRecordScreen parentV)
        {
            InitializeComponent();
            parent = parentV;
        }

        private void button_Click(object sender, RoutedEventArgs e)
        {
            if(LabResTextBox.Text.Length>0) {
             parent.AddLabResult(LabResTextBox.Text);
             MessageBox.Show("New Lab Result Added. Add another.");
             LabResTextBox.Text = "";
            }
        }

        private void button1_Click(object sender, RoutedEventArgs e)
        {
            if(LabResTextBox.Text.Length>0) {
             parent.AddLabResult(LabResTextBox.Text);
             MessageBox.Show("New Lab Result Added.");
            }
            this.Close();
        }
    }
}
