﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace MedicalRecords
{
    /// <summary>
    /// Interaction logic for loginscreen.xaml
    /// </summary>
    public partial class loginscreen : Window
    {
        public loginscreen()
        {
            InitializeComponent();
        }

        private void loginbutton_Click(object sender, RoutedEventArgs e)
        {
         MedicalRecordClassLibrary.User user = new MedicalRecordClassLibrary.User();
         if(user.Login(usernametextbox.Text.Trim(),passwordBox.Password.Trim())){
          (new PatientDatabase(user)).Show();
          this.Close();
         }else{
          MessageBox.Show("Incorrect username/password combination.","Login Failed");
         }
        }
    }
}
