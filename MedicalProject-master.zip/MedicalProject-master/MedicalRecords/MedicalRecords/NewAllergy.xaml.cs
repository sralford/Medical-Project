﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace MedicalRecords
{
    /// <summary>
    /// Interaction logic for NewAllergy.xaml
    /// </summary>
    public partial class NewAllergy : Window
    {

        private PatientRecordScreen parent;

        public NewAllergy(PatientRecordScreen parentV)
        {
            InitializeComponent();
            parent = parentV;
        }

        private void addAnotherbutton_Click(object sender, RoutedEventArgs e)
        {
            if(allergyTextBox.Text.Length>0){
             parent.AddAllergy(allergyTextBox.Text);
             MessageBox.Show("New Allergy Saved. Add another.");
             allergyTextBox.Text = "";
            }
        }

        private void doneButton_Click(object sender, RoutedEventArgs e)
        {
            if(allergyTextBox.Text.Length>0){
             parent.AddAllergy(allergyTextBox.Text);
             MessageBox.Show("New Allergy Saved.");
            }
            this.Close();
        }
    }
}
